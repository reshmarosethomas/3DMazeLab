﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
namespace Tinylytics {
public class Tinylytics_Config : ScriptableObject {
		public Texture2D logo;
		public string header, text;

		public string deploymentID;
}

}